import 'package:app1/app/components/my_app_bar.dart';
import 'package:app1/app/pages/calls/calls_view.dart';
import 'package:app1/app/pages/chats/chat_view.dart';
import 'package:app1/app/pages/status/status_page.dart';
import 'package:flutter/material.dart';

class App extends StatelessWidget {
  const App({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: buildAppBar(),
        body: TabBarView(
          children: [
            Icon(Icons.photo),
            ChatList(),
            StatusPage(),
            CallsList(),
          ],
        ),
      ),
    );
  }
}