  import 'package:flutter/material.dart';

TabBar buildTabBar() {
    return TabBar(
          indicatorColor: Colors.white,
          indicatorWeight: 3.1,
          tabs: [
            Tab(icon: Icon(Icons.camera_alt)),
            Text('CHATS'),
            Text('STATUS'),
            Text('CALLS'),
          ],
        );
  }