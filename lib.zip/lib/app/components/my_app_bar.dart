  import 'package:app1/app/components/more_button.dart';
import 'package:app1/app/components/my_tab_bar.dart';
import 'package:app1/app/components/search_button.dart';
import 'package:flutter/material.dart';

AppBar buildAppBar() {
    return AppBar(
        title: Text(
          "ZapZap",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 21.0,
          ),
        ),
        backgroundColor: Color(0xFF075E55),
        actions: <Widget>[
          SearchButton(),
          MoreButton(),
        ],
        bottom: buildTabBar(),
      );
  }