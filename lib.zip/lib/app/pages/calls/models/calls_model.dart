import 'dart:convert';

CallsModel callsModelFromJson(String str) => CallsModel.fromJson(json.decode(str));

String callsModelToJson(CallsModel data) => json.encode(data.toJson());

class CallsModel {
    String contato;
    String imageUrl;
    String date;
    String time;
    int statusCall;

    CallsModel({
        this.contato,
        this.imageUrl,
        this.date,
        this.time,
        this.statusCall,
    });

    factory CallsModel.fromJson(Map<String, dynamic> json) => CallsModel(
        contato: json["contato"],
        imageUrl: json["imageUrl"],
        time: json["time"],
        date: json["date"],
        statusCall: json["statusCall"]
    );

    Map<String, dynamic> toJson() => {
        "contato": contato,
        "imageUrl": imageUrl,
        "time": time,
        "date": date,
        "statusCall": statusCall,

    };
}