

import 'package:app1/app/pages/status/status_model.dart';

class StatusController {

  final String myImage = 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500';

  final List<StatusModel> statusList = [
    StatusModel(
      contato: "João Pedro",
      imageUrl:
          'https://images.pexels.com/photos/736716/pexels-photo-736716.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      time: '12:00',
      date: 'Yesterday',
      hasViewed: true,
    ),
    StatusModel(
      contato: "Matheus",
      imageUrl:
          'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      time: '15:00',
      date: 'Today',
      hasViewed: false,
    ),
    StatusModel(
      contato: "Maria",
      imageUrl:
          'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      time: '21:00',
      date: 'Today',
      hasViewed: true,
    ),
    StatusModel(
      contato: "Carlos",
      imageUrl:
          'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      time: '22:00',
      date: 'Today',
      hasViewed: false,
    ),
    StatusModel(
      contato: "Milla",
      imageUrl:
          'https://images.pexels.com/photos/1024311/pexels-photo-1024311.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      time: '07:00',
      date: 'Today',
      hasViewed: false,
    ),
    StatusModel(
      contato: "Felipe",
      imageUrl:
          'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      time: '19:00',
      date: 'Yesterday',
      hasViewed: true,
    ),
  ];
}