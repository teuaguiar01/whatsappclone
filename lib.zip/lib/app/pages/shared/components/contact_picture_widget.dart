import 'package:flutter/material.dart';

class ContactPicture extends StatelessWidget {
  final String imageUrl;
  const ContactPicture({
    Key key,
    @required this.imageUrl,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(100),
      child: Image.network(
        imageUrl,
        height: 50,
        width: 50,
      ),
    );
  }
}