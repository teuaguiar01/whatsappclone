import 'package:app1/app/pages/shared/components/contact_picture_widget.dart';
import 'package:flutter/material.dart';

class ChatWidget extends StatelessWidget {
  final String contato;
  final String imageUrl;
  final String horario;
  final StatusMessage statusMessage;
  final bool mute;
  final int mensagensNaoLidas;
  final String msgPreview;

  const ChatWidget({
    Key key,
    @required this.contato,
    @required this.imageUrl,
    @required this.horario,
    @required this.statusMessage,
    @required this.mute,
    @required this.msgPreview,
    this.mensagensNaoLidas,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          ContactPicture(imageUrl: imageUrl),
          SizedBox(width: 20),
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 15),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(width: 0.15, color: Colors.grey),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          contato,
                          style: new TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text(
                          horario,
                          style: new TextStyle(
                              fontWeight: FontWeight.w200, fontSize: 12),
                        ),
                      ],
                      ),
                  Row(
                    children: <Widget>[
                      buildIconStatus(statusMessage: statusMessage),
                      Text(
                        msgPreview,
                        style: new TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w400,
                          color: Colors.grey,
                        ),
                      ),
                      Spacer(),
                      if (mute) Icon(Icons.volume_off, color: Colors.grey),
                      if (mensagensNaoLidas > 0) ...[
                        SizedBox(width: 10),
                        NotReadMessages(mensagensNaoLidas: mensagensNaoLidas),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Icon buildIconStatus({StatusMessage statusMessage}) {
    Icon icon;
    switch (statusMessage) {
      case StatusMessage.VISUALIZADO:
        icon = Icon(
          Icons.done_all,
          size: 15,
          color: Colors.blue,
        );
        break;
      case StatusMessage.ENTREGUE:
        icon = Icon(
          Icons.done_all,
          size: 15,
          color: Colors.grey,
        );
        break;
      case StatusMessage.NAO_ENTREGUE:
        icon = Icon(
          Icons.done,
          size: 15,
          color: Colors.grey,
        );
        break;
    }
    return icon;
  }
}

class NotReadMessages extends StatelessWidget {
  const NotReadMessages({
    Key key,
    @required this.mensagensNaoLidas,
  }) : super(key: key);

  final int mensagensNaoLidas;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.green,
        shape: BoxShape.circle,
      ),
      child: Padding(
        padding: const EdgeInsets.all(6.0),
        child: Text(
          mensagensNaoLidas.toString(),
          style: new TextStyle(
            color: Colors.white,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

enum StatusMessage { VISUALIZADO, ENTREGUE, NAO_ENTREGUE }
