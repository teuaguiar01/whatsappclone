import 'package:app1/app/pages/chats/models/chat_model.dart';

class ChatController {

  

  final List<ChatModel> chatList = [
    ChatModel(
      contato: "João Pedro",
      imageUrl:
          'https://images.pexels.com/photos/736716/pexels-photo-736716.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      horario: '12:00',
      statusMessage: 0,
      mute: true,
      mensagensNaoLidas: 10,
      msgPreview: 'Oi galera',
    ),
    ChatModel(
      contato: "Matheus",
      imageUrl:
          'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      horario: '22:22',
      statusMessage: 2,
      mute: true,
      mensagensNaoLidas: 0,
      msgPreview: 'Vou nessa',
    ),
    ChatModel(
      contato: "Maria",
      imageUrl:
          'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      horario: '15:22',
      statusMessage: 1,
      mute: false,
      mensagensNaoLidas: 3,
      msgPreview: 'Ola! Tudo bem?',
    ),ChatModel(
      contato: "Carlos",
      imageUrl:
          'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      horario: '11:10',
      statusMessage: 0,
      mute: true,
      mensagensNaoLidas: 0,
      msgPreview: 'Ja ouviu falar da Hinode?',
    ),ChatModel(
      contato: "Milla",
      imageUrl:
          'https://images.pexels.com/photos/1024311/pexels-photo-1024311.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      horario: '15:00',
      statusMessage: 0,
      mute: false,
      mensagensNaoLidas: 0,
      msgPreview: 'Vou nessa',
    ),ChatModel(
      contato: "Felipe",
      imageUrl:
          'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      horario: '16:20',
      statusMessage: 1,
      mute: true,
      mensagensNaoLidas: 0,
      msgPreview: 'Vamo la!',
    ),
  ];
}